﻿$(document).ready(function () {
    alert("Hello");
})