﻿// Include gulp
var gulp = require('gulp');
var del = require('del');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var server = require('gulp-develop-server');

var config = {
    src: ['scripts/**/*.js', '!scripts/**/*.min.js'],
   // cssconfig: ['css/style.css', 'css/custom-style.css']
}

gulp.task('clean', function () {
    return del(['js/all.min.js']);
})

gulp.task('scripts', ['clean'], function () {
    return gulp.src(config.src)
      .pipe(uglify())
      .pipe(concat('all.min.js'))
      .pipe(gulp.dest('js/'));
});

gulp.task('watch', function () {
    return gulp.watch(config.src, ['scripts']);
});

gulp.task('run', function () {
    server.listen({ path: 'E:/Anil Kumar/Demo Application/NodeApi/Scripts/server.js' });
});

gulp.task('start', ['run','scripts', 'watch'], function () { });